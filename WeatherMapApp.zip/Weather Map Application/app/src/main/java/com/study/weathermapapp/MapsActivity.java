package com.study.weathermapapp;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST = 1;
    private static final String API_KEY = "ab4650472ddad2c8805514670775d096"; // OpenWeatherMap API key

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps); // should use FragmentContainerView in XML

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Log.e("MapInit", "Map Fragment is null");
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        } else {
            enableUserLocation();
        }

        mMap.setOnMapClickListener(latLng -> {
            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(latLng).title("Loading weather..."));
            fetchWeatherData(latLng.latitude, latLng.longitude);
        });
    }

    private void enableUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED && mMap != null) {

            mMap.setMyLocationEnabled(true);

            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng userLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 10));
                }
            });
        }
    }

    private void fetchWeatherData(double lat, double lon) {
        String apiUrl = "https://api.openweathermap.org/data/2.5/weather?lat=" +
                lat + "&lon=" + lon + "&appid=" + API_KEY + "&units=metric";

        new FetchWeatherTask(lat, lon).execute(apiUrl);
    }

    // AsyncTask to fetch weather data
    private static class FetchWeatherTask extends AsyncTask<String, Void, String> {
        private final double lat;
        private final double lon;

        public FetchWeatherTask(double lat, double lon) {
            this.lat = lat;
            this.lon = lon;
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL(params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream input = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(input);
                StringBuilder builder = new StringBuilder();
                int data = reader.read();
                while (data != -1) {
                    builder.append((char) data);
                    data = reader.read();
                }
                return builder.toString();
            } catch (Exception e) {
                Log.e("WeatherAPI", "Error: " + e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject json = new JSONObject(result);
                    String city = json.getString("name");
                    JSONObject main = json.getJSONObject("main");
                    double temp = main.getDouble("temp");
                    String weather = json.getJSONArray("weather")
                            .getJSONObject(0)
                            .getString("description");

                    MapsActivity activity = MapsActivityHolder.INSTANCE;
                    if (activity != null && activity.mMap != null) {
                        LatLng latLng = new LatLng(lat, lon);
                        activity.mMap.clear();
                        activity.mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title(city)
                                .snippet("Weather: " + weather + "\nTemp: " + temp + "°C"));
                    }
                } catch (Exception e) {
                    Log.e("WeatherParse", "Error parsing JSON: " + e.getMessage());
                }
            }
        }
    }

    // Helper to allow static access from AsyncTask
    private static class MapsActivityHolder {
        static MapsActivity INSTANCE;
    }

    @Override
    protected void onStart() {
        super.onStart();
        MapsActivityHolder.INSTANCE = this;
    }

    @Override
    protected void onStop() {
        super.onStop();
        MapsActivityHolder.INSTANCE = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            enableUserLocation();
        }
    }
}
