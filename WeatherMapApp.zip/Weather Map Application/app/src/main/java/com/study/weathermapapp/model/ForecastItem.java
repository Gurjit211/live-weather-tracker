package com.study.weathermapapp.model;

public class ForecastItem {
    private String date;
    private double temperature;
    private String description;

    public ForecastItem(String date, double temperature, String description) {
        this.date = date;
        this.temperature = temperature;
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public double getTemperature() {
        return temperature;
    }

    public String getDescription() {
        return description;
    }
}
