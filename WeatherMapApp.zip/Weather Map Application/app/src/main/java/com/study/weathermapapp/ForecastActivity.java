package com.study.weathermapapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.study.weathermapapp.adapter.ForecastAdapter;
import com.study.weathermapapp.model.ForecastItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ForecastActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ForecastAdapter adapter;
    private final ArrayList<ForecastItem> forecastList = new ArrayList<>();

    private final double latitude = 43.7315;
    private final double longitude = -79.7624;
    private static final String API_KEY = "ab4650472ddad2c8805514670775d096";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast);

        recyclerView = findViewById(R.id.rvForecast); // ✅ Match with activity_forecast.xml
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ForecastAdapter(forecastList);
        recyclerView.setAdapter(adapter);

        fetchForecastData();
    }

    private void fetchForecastData() {
        new Thread(() -> {
            try {
                String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?lat=" +
                        latitude + "&lon=" + longitude + "&appid=" + API_KEY + "&units=metric";

                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream input = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(input);
                StringBuilder builder = new StringBuilder();
                int data = reader.read();
                while (data != -1) {
                    builder.append((char) data);
                    data = reader.read();
                }

                JSONObject json = new JSONObject(builder.toString());
                JSONArray list = json.getJSONArray("list");

                forecastList.clear();

                for (int i = 0; i < list.length(); i++) {
                    JSONObject obj = list.getJSONObject(i);
                    String dt_txt = obj.getString("dt_txt");
                    double temp = obj.getJSONObject("main").getDouble("temp");
                    String weather = obj.getJSONArray("weather").getJSONObject(0).getString("description");

                    forecastList.add(new ForecastItem(dt_txt, temp, weather));
                }

                runOnUiThread(() -> adapter.notifyDataSetChanged());

            } catch (Exception e) {
                Log.e("ForecastAPI", "Error: " + e.getMessage());
                runOnUiThread(() ->
                        Toast.makeText(ForecastActivity.this, "Failed to load forecast", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
